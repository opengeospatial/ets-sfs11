/*
** File: wkb.h 
** Content: This file contains header information used in wkt2wkb and wkb2wkt,
**          software for processing the Well-Known Text format for geometry
**          described in OpenGIS Simle Features for SQL, Revision 1.0
**
** Author: Kurt Buehler, Open GIS Consortium, Inc.
** Date: 7/27/1998
**
** Revision History:
**     1.0 - Initial Release, 7/27/1998
**     1.1 - Fixed memory leaks by adding free routines, also added new
**           library routine freewkb(), 8/31/98 
**           Contributed by:
**              Robert Power
**              robert.power@cmis.csiro.au   Software Engineer
**              CSIRO Mathematical and Information Sciences
**              Canberra Laboratory
**              PO Box 664      tel: +61 6 216 7039
**              Canberra ACT 2601 AUSTRALIA.   fax: +61 6 216 7112
**              http://www.cmis.csiro.au/sis
**
*/

/*
** Copyright 1998, Open GIS Consortium, Inc.
**
** WHILE THE SOFTWARE IN THIS FILE IS BELIEVED TO BE ACCURATE, 
** THE OPEN GIS CONSORTIUM MAKES NO WARRANTY OF ANY KIND WITH REGARD TO 
** THIS MATERIAL INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The Open GIS
** Consortium shall not be liable for errors contained herein or for incidental
** or consequential damages in connection with the furnishing, performance or 
** use of this material.
**
** This document contains information, which is protected by copyright. All 
** Rights Reserved. Any part of this work covered by copyright herein may be 
** reproduced or used in any form or by any means graphic, electronic, or 
** mechanical, including photocopying, recording, taping, or information 
** storage and retrieval systems as long as this copyright notice remains.
**
** RESTRICTED RIGHTS LEGEND. Use, duplication, or disclosure by government is 
** subject to restrictions as set forth in subdivision (c)(1)(ii) of the Right 
** in Technical Data and Computer Software Clause at DFARS 252.227.7013
** 
** OpenGIS(R) is a trademark or registered trademark of Open GIS Consortium, 
** Inc. in the United States and in other countries.
*/

#ifndef _WKB_H
#define _WKB_H

/* the type is POINT */
typedef struct _point {
    double x;
    double y;
} Point; 

/* the type is MULTIPOINT */
typedef struct _pointList {
    struct _point *point;
    struct _pointList *next;
} PointList;

/* the type is LINESTRING */
typedef PointList Linestring;

/* 
*  if the type is POLYGON, the first line string is interpreted
*  as the exterior ring, all others are interior rings.
*  if the type if MULTILINESTRING, then all are treated as linestrings
*/
typedef struct _linestringList {
    struct _pointList *linestring;
	struct _linestringList *next;
} LinestringList;

typedef struct _polygonList {
    struct _linestringList *polygon;
	struct _polygonList *next;
} PolygonList;

typedef struct _geometry {
    int type;
	union _value {
	    Point *point_val;
		Linestring *linestring_val;
		LinestringList *polygon_val;
		PointList *multipoint_val;
		LinestringList *multilinestring_val;
		PolygonList *multipolygon_val;
	} value;
} Geometry;

typedef struct _geometryCollection {
    Geometry *geometry;
	struct _geometryCollection *next;
} GeometryCollection;

typedef struct _parsedInput {
	int type;
	union _pvalue {
		Geometry *geometry_val;
		GeometryCollection *geometrycollection_val;
	} value;
}ParsedInput;

typedef char byte;

typedef unsigned int uint32;

#define WKBXDR 0
#define WKBNDR 1

#define WKBMINTYPE 1

#define WKBPOINT 1
#define WKBLINESTRING 2
#define WKBPOLYGON 3
#define WKBMULTIPOINT 4
#define WKBMULTILINESTRING 5
#define WKBMULTIPOLYGON 6
#define WKBGEOMETRYCOLLECTION 7

#define WKBMAXTYPE 7

#define WKBGEOMETRY 0

typedef struct _linearRing {
	uint32 numPoints;
	Point *points;
} LinearRing;

typedef struct _WKBPoint {
	byte byteorder;
	uint32 wkbType;
	Point point;
} WKBPoint;

typedef struct _WKBLineString {
	byte byteorder;
	uint32 wkbType;
	uint32 numPoints;
	Point *points;
} WKBLineString;

typedef struct _WKBPolygon {
	byte byteorder;
	uint32 wkbType;
	uint32 numRings;
	LinearRing *rings;
} WKBPolygon;

typedef struct _WKBMultiPoint {
	byte byteorder;
	uint32 wkbType;
	uint32 num_wkbPoints;
	WKBPoint *wkbPoints;
} WKBMultiPoint;

typedef struct _WKBMultiLineString {
	byte byteorder;
	uint32 wkbType;
	uint32 num_wkbLineStrings;
	WKBLineString *wkbLineStrings;
} WKBMultiLineString;

typedef struct _WKBMultiPolygon {
	byte byteorder;
	uint32 wkbType;
	uint32 num_wkbPolygons;
	WKBPolygon *wkbPolygons;
} WKBMultiPolygon;

typedef struct _WKBGeometry {
	/* 
	 * NOTE: The geometry_type member is not strictly supported in 
	 * revison 1.0 of the SQL specification as you will see from the 
	 * definition of WKBGeometryCollection (and its commentary) below.
	 */
	int geometry_type;
	union _gvalue {
		WKBPoint *point;
		WKBLineString *linestring;
		WKBPolygon *polygon;
		WKBMultiPoint *multipoint;
		WKBMultiLineString *multilinestring;
		WKBMultiPolygon *multipolygon;
	} value;
} WKBGeometry;

typedef struct _WKBGeometryCollection {
	byte byteorder;
	uint32 wkbType;
	uint32 num_wkbGeometries;
	/*
	 * NOTE: This is where the above comes in. If geometry_type was
	 * available, then heterogeneous collections would be possible.
	 * As it is, they are not.
	 */
	WKBGeometry *wkbGeometries;
} WKBGeometryCollection;

typedef struct _WKBResult {
	int result_type;
	union _rvalue {
		WKBGeometry *g_val;
		WKBGeometryCollection *gc_val;
	} result_value;
} WKBResult;

#define WKTDEBUG 0
#define WKTHEX 1
#define WKTBINARY 2

#define E_TMPOUT 1 /* error opening the temporary file for output */
#define E_TMPIN 2 /* error opening the temporary file for input */
#define E_NOINPUT 3 /* the input string is empty */
#define E_BINFILE 4 /* could not open input binary file */
#define E_UBO 5 /* problem with the input binary, byte order unknown */
#define E_UT 6 /* problem with the input binary, type unknown */

#ifndef _WKBLIB
extern int wkterr;
extern char wkterrmsg[1024];
extern int wkberr;
extern char wkberrmsg[1024];
#endif /* _WKBLIB */

WKBResult *wkt2wkb(char *wktInput);
char *wkb2wkt(char *filename);

#include <stdio.h>

void emitwkb(WKBResult *res, int outType, FILE *fpout);

void freewkb(WKBResult * result);

#endif /* _WKB_H */
