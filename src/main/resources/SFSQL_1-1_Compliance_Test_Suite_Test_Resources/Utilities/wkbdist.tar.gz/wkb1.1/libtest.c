
#include "wkb.h"

static char gctext[] = { 
   "GEOMETRYCOLLECTION ( \
    MULTIPOLYGON(  ( (28 26, 28 0, 84 0, 84 42, 28 26), \
    (52 18, 66 23, 73 9, 48 6, 52 18) ) , \
	( (59 18, 67 18, 67 13, 59 13, 59 18) ) ), \
	POLYGON( ( 50 31, 54 31, 54 29, 50 29, 50 31) ),\
	POINT( 44 31 ), LINESTRING( 0 18, 10 21, 16 23, 28 26, 44 31 ), \
	MULTILINESTRING ( (28 26, 28 0, 84 0, 84 42, 28 26), \
	(52 18, 66 23, 73 9, 48 6, 52 18), (59 18, 67 18, 67 13, 59 13, 59 18)), \
	MULTIPOINT( (23 23), (34 34) ))"
};

int main()
{
    WKBResult *r;
	char *s;

	r = wkt2wkb(gctext);
	emitwkb(r, WKTDEBUG, stderr);
	freewkb(r);
	s = wkb2wkt("l.dat");
	printf("WKB2WKT: l.dat: %s\n",s);
	free(s);
	s = wkb2wkt("unixl.dat");
	printf("WKB2WKT: unixl.dat: %s\n",s);
	free(s);
	s = wkb2wkt("p.dat");
	printf("WKB2WKT: p.dat: %s\n",s);
	free(s);

	s = wkb2wkt("l.dat");
	r = wkt2wkb(s);
	free(s);
	emitwkb(r, WKTDEBUG, stderr);
	freewkb(r);
	s = wkb2wkt("wrongname.dat");
	if ( s == NULL ) {
		fprintf(stderr, "Oops: %s\n", wkberrmsg);
	} else {
		printf("WKB2WKT: p.dat: %s\n",s);
		free(s);
	}
}
