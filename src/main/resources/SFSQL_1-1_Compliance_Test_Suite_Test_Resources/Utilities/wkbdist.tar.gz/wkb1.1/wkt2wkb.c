/*
** File: wkt2wkb.c 
** Content: This file contains code for processing the Well-Known Text 
**          format for geometry described in OpenGIS Simle Features for 
**          SQL, Revision 1.0. It accepts Well-Known Text as input and
**          generates as output:
**          1. a verbose text representation (-d) 
**          2. the Well-Known Binary representation (-b)
**          3. a hexidecimal version of 2 (-x)
**
** Author: Kurt Buehler, Open GIS Consortium, Inc.
** Date: 7/27/1998
**
** Revision History:
**     1.0 - Initial Release, 7/27/1998
**     1.1 - Fixed memory leaks by adding free routines, also added new
**           library routine freewkb(), 8/31/98 
**           Contributed by:
**              Robert Power
**              robert.power@cmis.csiro.au   Software Engineer
**              CSIRO Mathematical and Information Sciences
**              Canberra Laboratory
**              PO Box 664      tel: +61 6 216 7039
**              Canberra ACT 2601 AUSTRALIA.   fax: +61 6 216 7112
**              http://www.cmis.csiro.au/sis
**
*/

/*
** Copyright 1998, Open GIS Consortium, Inc.
**
** WHILE THE SOFTWARE IN THIS FILE IS BELIEVED TO BE ACCURATE, 
** THE OPEN GIS CONSORTIUM MAKES NO WARRANTY OF ANY KIND WITH REGARD TO 
** THIS MATERIAL INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The Open GIS
** Consortium shall not be liable for errors contained herein or for incidental
** or consequential damages in connection with the furnishing, performance or 
** use of this material.
**
** This document contains information, which is protected by copyright. All 
** Rights Reserved. Any part of this work covered by copyright herein may be 
** reproduced or used in any form or by any means graphic, electronic, or 
** mechanical, including photocopying, recording, taping, or information 
** storage and retrieval systems as long as this copyright notice remains.
**
** RESTRICTED RIGHTS LEGEND. Use, duplication, or disclosure by government is 
** subject to restrictions as set forth in subdivision (c)(1)(ii) of the Right 
** in Technical Data and Computer Software Clause at DFARS 252.227.7013
** 
** OpenGIS(R) is a trademark or registered trademark of Open GIS Consortium, 
** Inc. in the United States and in other countries.
*/

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <netinet/in.h>
#include "wkb.h"
#include "grammar.tab.h"

int wkterr;
char wkterrmsg[1024];

int DEBUG;
int HEX;
int BINARY;

#define HEXFORMAT "%1x%1x"

extern FILE *yyin;

extern int errno;

extern int optind;
extern char *optarg;

extern ParsedInput *global_parsed;

char getbits(char x, int p, int n);
WKBResult *buildwkb();

void usage(char *s);

char *wkbTypes[] = {
    "",
    "WKBPOINT",
    "WKBLINESTRING",
    "WKBPOLYGON",
    "WKBMULTIPOINT",
    "WKBMULTILINESTRING",
    "WKBMULTIPOLYGON",
    "WKBGEOMETRYCOLLECTION"
};

#ifndef _WKBLIB
int
main( int argc, char **argv) 
{
    int use_stdin = 1;
    int use_stdout = 1;
    char *use_file = 0;
    register int c = 0;
    FILE *fp;
    FILE *fpout;
    int outType;

    DEBUG = 0;
    HEX = 0;
    BINARY = 0;
                    
    while((c = getopt(argc, argv, "dhxbo:")) != EOF) {
        switch (c) {
            case 'd': 
                DEBUG = 1; 
                break;
            case 'h': 
                usage(argv[0]); 
                exit(1);
                break;
            case 'x': 
                HEX = 1; 
                break;
            case 'b': 
                BINARY = 1; 
                break;
            case 'o':
                if ( (fpout = fopen(optarg, "w")) == NULL ) {
                    char errstring[1024];

                    sprintf(errstring, "%s: Could not open file \"%s\"\n\tReason",
                    argv[0], optarg);
                    perror(errstring);
                    exit(0);
                }
                use_stdout = 0;
                break;
        }
    }

    if ( !DEBUG && !HEX && !BINARY ) {
        fprintf(stderr, "Must specify at least one output format\n");
        usage(argv[0]);
        exit(0);
    }

    if ( DEBUG && HEX ) {
        fprintf(stderr, "Cannot output both HEX and DEBUG forms\n");
        usage(argv[0]);
        exit(0);
    }

    if ( DEBUG && BINARY ) {
        fprintf(stderr, "Cannot output both DEBUG and BINARY forms\n");
        usage(argv[0]);
        exit(0);
    }

    if ( HEX && BINARY ) {
        fprintf(stderr, "Cannot output both HEX and BINARY forms\n");
        usage(argv[0]);
        exit(0);
    }

    if ( DEBUG )
        outType = WKTDEBUG;
    else if ( HEX )
        outType = WKTHEX;
    else
        outType = WKTBINARY;
                                
    if ( optind < argc ) {
        use_file = argv[optind];
        use_stdin = 0;
    } 
                                            
    if ( use_stdin ) {
        yyin = stdin;
    } else {
        if ( (fp = fopen(use_file, "r")) == NULL ) {
            char errstring[1024];

            sprintf(errstring, "%s: Could not open file \"%s\"\n\tReason",
            argv[0], use_file);
            perror(errstring);
            exit(0);
        }
        yyin = fp;
    }

    if ( use_stdout ) {
        fpout = stdout;
    }

    yyparse();
    emitwkb(buildwkb(), outType, fpout);

    exit(1);
}
#else /* _WKBLIB */

WKBResult *
wkt2wkb(char *wktInput) 
{
    FILE *tmpoutfp;
    FILE *tmpinfp;
    /* 
     * This is bogus, but I didn't have time to figure out how to
     * make the input character stream act like a file without
     * actually making it one...
     */
    if ((tmpoutfp = fopen("wkt2wkb.tmp", "w")) == NULL ) {
        wkterr = E_TMPOUT;
        sprintf(wkterrmsg, "Could not open temp file for input\nReason %s\n",strerror(errno));
        return(NULL);
    }
    fprintf(tmpoutfp, "%s", wktInput);
    fclose(tmpoutfp);
    if ((tmpinfp = fopen("wkt2wkb.tmp", "r")) == NULL ) {
        wkterr = E_TMPIN;
        sprintf(wkterrmsg, "Could not open temp file for input\nReason %s\n",strerror(errno));
        unlink("wkt2wkb.tmp");
        return(NULL);
    }
    yyin = tmpinfp;
    yyparse();
    fclose(tmpinfp);
    unlink("wkt2wkb.tmp");
    return(buildwkb());
}

#endif /* _WKBLIB */

#ifndef _WKBLIB
void
usage(char *s)
{
    fprintf(stderr,"Usage: %s [-bdhx] [-o output_filename] [input_filename]\n", s);
}
#endif /* _WKBLIB */

extern char *yytext;

#ifndef _WKBLIB
yyerror(char *s)
{
    if ( yytext != NULL )
        fprintf(stderr,"%s, at or near \"%s\"\n",s, yytext);
    else
        fprintf(stderr,"%s, missing paren?\n",s);
}
#else /* _WKBLIB */
yyerror(char *s)
{
    if ( yytext != NULL )
        fprintf(stderr,"%s, at or near \"%s\"\n",s, yytext);
    else
        fprintf(stderr,"%s, missing paren?\n",s);
}
#endif /* _WKBLIB */
        
char 
getbits(char x, int p, int n)
{
    return((x >> (p+1-n)) & ~(~0 << n));
}

void
emit_byteorder(byte byteorder, int outType, FILE *fpout)
{
    /* one byte -> byteorder */
    if ( outType == WKTDEBUG ) 
        fprintf(fpout,"Byteorder: %s\n", byteorder ? "WKBNDR":"WKBXDR");
    if ( outType == WKTHEX ) 
            fprintf(fpout, HEXFORMAT, 
                getbits((char)byteorder,7,4),
                getbits((char)byteorder,3,4));
    if ( outType == WKTBINARY ) {
        int fdout = fileno(fpout);

        write(fdout, &byteorder, 1);
    }
}

void
emit_wkbType(uint32 wkbType, int outType, FILE *fpout)
{
    char ui[4];

    bzero((void *)ui, 4);

    /* four bytes -> wkbType */
    if ( outType == WKTDEBUG ) fprintf(fpout,"wkbType: %d %s\n", wkbType, wkbTypes[wkbType]);
    ui[0] = ((char *) &wkbType)[0];
    ui[1] = ((char *) &wkbType)[1];
    ui[2] = ((char *) &wkbType)[2];
    ui[3] = ((char *) &wkbType)[3];
    if ( outType == WKTHEX ) {
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[0],7,4),
                getbits((char)ui[0],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[1],7,4),
                getbits((char)ui[1],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[2],7,4),
                getbits((char)ui[2],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[3],7,4),
                getbits((char)ui[3],3,4));
/*
        fprintf(fpout, "%08x ", ui[0]);
        fprintf(fpout, "%08x ", ui[1]);
        fprintf(fpout, "%08x ", ui[2]);
        fprintf(fpout, "%08x ", ui[3]);
*/
    }
    if ( outType == WKTBINARY ) {
        int fdout = fileno(fpout);

        write(fdout, &wkbType, 4);
    }
}

void
emit_Point(Point *point, int outType, FILE *fpout)
{
    char d[8];

    bzero((void *)d, 8);

    /* eight bytes -> point->x */
    if ( outType == WKTDEBUG ) fprintf(fpout, "x: %f ", point->x);

    d[0] = ((char *) &point->x)[0];
    d[1] = ((char *) &point->x)[1];
    d[2] = ((char *) &point->x)[2];
    d[3] = ((char *) &point->x)[3];
    d[4] = ((char *) &point->x)[4];
    d[5] = ((char *) &point->x)[5];
    d[6] = ((char *) &point->x)[6];
    d[7] = ((char *) &point->x)[7];

    if ( outType == WKTHEX ) {
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[0],7,4),
                getbits((char)d[0],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[1],7,4),
                getbits((char)d[1],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[2],7,4),
                getbits((char)d[2],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[3],7,4),
                getbits((char)d[3],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[4],7,4),
                getbits((char)d[4],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[5],7,4),
                getbits((char)d[5],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[6],7,4),
                getbits((char)d[6],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[7],7,4),
                getbits((char)d[7],3,4));
/*
        fprintf(fpout, "%08x ", d[0]);
        fprintf(fpout, "%08x ", d[1]);
        fprintf(fpout, "%08x ", d[2]);
        fprintf(fpout, "%08x ", d[3]);
        fprintf(fpout, "%08x ", d[4]);
        fprintf(fpout, "%08x ", d[5]);
        fprintf(fpout, "%08x ", d[6]);
        fprintf(fpout, "%08x ", d[7]);
*/
    }
    if ( outType == WKTBINARY ) {
        int fdout = fileno(fpout);

        write(fdout, &point->x, 8);
    }

    /* eight bytes -> point->y */
    if ( outType == WKTDEBUG ) {
        fprintf(fpout, "y: %f\n", point->y);
    }

    d[0] = ((char *) &point->y)[0];
    d[1] = ((char *) &point->y)[1];
    d[2] = ((char *) &point->y)[2];
    d[3] = ((char *) &point->y)[3];
    d[4] = ((char *) &point->y)[4];
    d[5] = ((char *) &point->y)[5];
    d[6] = ((char *) &point->y)[6];
    d[7] = ((char *) &point->y)[7];

    if ( outType == WKTHEX ) {
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[0],7,4),
                getbits((char)d[0],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[1],7,4),
                getbits((char)d[1],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[2],7,4),
                getbits((char)d[2],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[3],7,4),
                getbits((char)d[3],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[4],7,4),
                getbits((char)d[4],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[5],7,4),
                getbits((char)d[5],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[6],7,4),
                getbits((char)d[6],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)d[7],7,4),
                getbits((char)d[7],3,4));
/*
        fprintf(fpout, "%08x ", d[0]);
        fprintf(fpout, "%08x ", d[1]);
        fprintf(fpout, "%08x ", d[2]);
        fprintf(fpout, "%08x ", d[3]);
        fprintf(fpout, "%08x ", d[4]);
        fprintf(fpout, "%08x ", d[5]);
        fprintf(fpout, "%08x ", d[6]);
        fprintf(fpout, "%08x ", d[7]);
*/
    }
    if ( outType == WKTBINARY ) {
        int fdout = fileno(fpout);
        write(fdout, &point->y, 8);
    }

}

void
emit_num(uint32 n, int outType, FILE *fpout)
{
    char ui[4];

    bzero((void *)ui, 4);

    ui[0] = ((char *) &n)[0];
    ui[1] = ((char *) &n)[1];
    ui[2] = ((char *) &n)[2];
    ui[3] = ((char *) &n)[3];
    if ( outType == WKTHEX ) {
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[0],7,4),
                getbits((char)ui[0],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[1],7,4),
                getbits((char)ui[1],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[2],7,4),
                getbits((char)ui[2],3,4));
        fprintf(fpout, HEXFORMAT,
                getbits((char)ui[3],7,4),
                getbits((char)ui[3],3,4));
/*
        fprintf(fpout, "%08x ", ui[0]);
        fprintf(fpout, "%08x ", ui[1]);
        fprintf(fpout, "%08x ", ui[2]);
        fprintf(fpout, "%08x ", ui[3]);
*/
    }
    if ( outType == WKTBINARY ) {
        int fdout = fileno(fpout);
        write(fdout, &n, 4);
    }
}

void
emit_numPoints(uint32 n, int outType, FILE *fpout)
{
    /* emit the number of points */
    if ( outType == WKTDEBUG ) fprintf(fpout,"numPoints: %d\n", n);
    emit_num(n, outType, fpout);
}

void
emit_numwkbPoints(uint32 n, int outType, FILE *fpout)
{
    /* emit the number of points */
    if ( outType == WKTDEBUG ) fprintf(fpout,"num_wkbPoints: %d\n", n);
    emit_num(n, outType, fpout);
}

void
emit_numRings(uint32 n, int outType, FILE *fpout)
{
    /* emit the number of points */
    if ( outType == WKTDEBUG ) fprintf(fpout,"numRings: %d\n", n);
    emit_num(n, outType, fpout);
}

void
emit_numwkbLineStrings(uint32 n, int outType, FILE *fpout)
{
    /* emit the number of points */
    if ( outType == WKTDEBUG ) fprintf(fpout,"num_wkbLineStrings: %d\n", n);
    emit_num(n, outType, fpout);
}

void
emit_numwkbPolygons(uint32 n, int outType, FILE *fpout)
{
    /* emit the number of points */
    if ( outType == WKTDEBUG ) fprintf(fpout,"num_wkbPolygons: %d\n", n);
    emit_num(n, outType, fpout);
}

byte
get_byteorder()
{
    u_short host = 5;
    u_short net;

    /* determine the byteorder */
    net = htons(host);
    if ( net == host ) {
        return(WKBXDR); /* big endian */
    } else {
        return(WKBNDR); /* little endian */
    }
}

void
emit_geo(WKBGeometry *geoptr, int outType, FILE *fpout)
{
    uint32 byteorder;
    byteorder = get_byteorder();

    if ( geoptr != NULL ) {
        switch(geoptr->geometry_type) {
            case WKBPOINT:
                { 
                    if ( outType == WKTDEBUG ) fprintf(fpout,"POINT:\n");
                    emit_byteorder(geoptr->value.point->byteorder, outType, fpout);
                    emit_wkbType(geoptr->value.point->wkbType, outType, fpout);
                    emit_Point(&geoptr->value.point->point, outType, fpout);
                }
                break;
            case WKBLINESTRING:
                { 
                    int i;

                    if ( outType == WKTDEBUG ) fprintf(fpout,"LINESTRING:\n");
                    emit_byteorder(geoptr->value.linestring->byteorder, outType, fpout);
                    emit_wkbType(geoptr->value.linestring->wkbType, outType, fpout);
                    emit_numPoints(geoptr->value.linestring->numPoints, outType, fpout);

                    for ( i = 0; i < geoptr->value.linestring->numPoints; i++ ) {
                        if ( outType == WKTDEBUG ) fprintf(fpout,"Vertex %d:\n",i);
                        emit_Point(&geoptr->value.linestring->points[i], outType, fpout);
                    }
                }
                break;
            case WKBPOLYGON:
                {
                    int i, j;

                    if ( outType == WKTDEBUG ) fprintf(fpout,"POLYGON:\n");
                    emit_byteorder(geoptr->value.polygon->byteorder, outType, fpout);
                    emit_wkbType(geoptr->value.polygon->wkbType, outType, fpout);
                    emit_numRings(geoptr->value.polygon->numRings, outType, fpout);

                    for( i = 0; i < geoptr->value.polygon->numRings; i++ ) {
                        if ( outType == WKTDEBUG ) {
                            if ( i == 0 ) 
                                fprintf(fpout,"Exterior Ring:\n");
                            else 
                                fprintf(fpout,"Interior Ring %d:\n", i);
                        }
                        /* emit the number of points */
                        emit_numPoints(geoptr->value.polygon->rings[i].numPoints, outType, fpout);

                        for ( j = 0; j < geoptr->value.polygon->rings[i].numPoints; j++ ) {
                            emit_Point(&geoptr->value.polygon->rings[i].points[j], outType, fpout);
                        }
                    }
                }
                break;
            case WKBMULTIPOINT:
                {
                    int i;

                    if ( outType == WKTDEBUG ) fprintf(fpout,"MULTIPOINT:\n");
                    emit_byteorder(geoptr->value.multipoint->byteorder, outType, fpout);
                    emit_wkbType(geoptr->value.multipoint->wkbType, outType, fpout);
                    emit_numwkbPoints(geoptr->value.multipoint->num_wkbPoints, outType, fpout);

                    for ( i = 0; i < geoptr->value.multipoint->num_wkbPoints; i++ ) {
                        emit_byteorder(geoptr->value.multipoint->wkbPoints[i].byteorder, outType, fpout);
                        emit_wkbType(geoptr->value.multipoint->wkbPoints[i].wkbType, outType, fpout);
                        emit_Point(&geoptr->value.multipoint->wkbPoints[i].point, outType, fpout);
                    }
                }
                break;
            case WKBMULTILINESTRING:
                {
                    int i, j;
                    if ( outType == WKTDEBUG ) fprintf(fpout,"MULTILINESTRING:\n");
                    emit_byteorder(geoptr->value.multilinestring->byteorder, outType, fpout);
                    emit_wkbType(geoptr->value.multilinestring->wkbType, outType, fpout);
                    emit_numwkbLineStrings(geoptr->value.multilinestring->num_wkbLineStrings, outType, fpout);

                    for ( i = 0; i < geoptr->value.multilinestring->num_wkbLineStrings; i++ ) {
                        if ( outType == WKTDEBUG ) fprintf(fpout,"Line String %d:\n", i);
                        emit_byteorder( geoptr->value.multilinestring->wkbLineStrings[i].byteorder , outType, fpout);
                        emit_wkbType( geoptr->value.multilinestring->wkbLineStrings[i].wkbType , outType, fpout);
                        emit_numPoints(geoptr->value.multilinestring->wkbLineStrings[i].numPoints, outType, fpout);

                        for ( j = 0; j < geoptr->value.multilinestring->wkbLineStrings[i].numPoints; j++ ) {
                            emit_Point(&geoptr->value.multilinestring->wkbLineStrings[i].points[j], outType, fpout);
                        }
                    }
                }
                break;
            case WKBMULTIPOLYGON:
                {
                    int i, j, k;

                    if ( outType == WKTDEBUG ) fprintf(fpout,"MULTIPOLYGON:\n");
                    emit_byteorder(geoptr->value.multipolygon->byteorder, outType, fpout);
                    emit_wkbType(geoptr->value.multipolygon->wkbType, outType, fpout);
                    emit_numwkbPolygons( geoptr->value.multipolygon->num_wkbPolygons, outType, fpout);
                
                    for ( i = 0; i < geoptr->value.multipolygon->num_wkbPolygons; i++ ) {
                        emit_byteorder(geoptr->value.multipolygon->wkbPolygons[i].byteorder, outType, fpout);
                        emit_wkbType(geoptr->value.multipolygon->wkbPolygons[i].wkbType, outType, fpout);
                        emit_numRings(geoptr->value.multipolygon->wkbPolygons[i].numRings, outType, fpout);

                        for ( j = 0; j < geoptr->value.multipolygon->wkbPolygons[i].numRings; j++ ) {
                            if ( outType == WKTDEBUG ) {
                                if ( j == 0 ) {
                                    fprintf(fpout,"Exterior Ring:\n");
                                } else {
                                    fprintf(fpout,"Interior Ring %d:\n", j);
                                }
                            }
                            emit_numPoints(geoptr->value.multipolygon->wkbPolygons[i].rings[j].numPoints, outType, fpout);

                            for ( k = 0; k < geoptr->value.multipolygon->wkbPolygons[i].rings[j].numPoints; k++ ) {
                                emit_Point(&geoptr->value.multipolygon->wkbPolygons[i].rings[j].points[k], outType, fpout);
                            }
                        } 
                    }
                }
                break;
        }
    }
}

void
emit_geoc(WKBGeometryCollection *geocptr, int outType, FILE *fpout)
{
    int i;
    WKBGeometryCollection *gcptr = geocptr;

    if ( outType == WKTDEBUG ) fprintf(fpout,"GEOCOLLECTION:\n");
    emit_byteorder(geocptr->byteorder, outType, fpout);
    emit_wkbType(geocptr->wkbType, outType, fpout);
    emit_num(geocptr->num_wkbGeometries, outType, fpout);

    for ( i = 0; i < geocptr->num_wkbGeometries; i++ ) {
        emit_geo(&gcptr->wkbGeometries[i], outType, fpout);
    }
}

void
emitwkb(WKBResult *ptr, int outType, FILE *fpout) 
{

    if ( ptr == NULL ) {
        fprintf(stderr,"Oops...parsed nothing\n");
        exit(0);
    }

    switch(ptr->result_type) {
        case WKBGEOMETRY:
            emit_geo(ptr->result_value.g_val, outType, fpout);
            break;
        case WKBGEOMETRYCOLLECTION:
            emit_geoc(ptr->result_value.gc_val, outType, fpout);
            break;
    }

}

void
build_geo(Geometry *geoptr, WKBGeometry *gresult)
{
    int cnt = 0;
    int vcnt = 0;
    int rcnt = 0;
    int pcnt = 0;
    Point *pt; 
    PointList *ptlist;
    LinestringList *linelist;
    PolygonList *polylist;
    Geometry *geo;
    GeometryCollection *geoc;
    uint32 byteorder;
    byteorder = get_byteorder();

    if ( geoptr != NULL ) {
        switch(geoptr->type) {
            case POINT:
                { 
                    WKBPoint *wkbPoint = (WKBPoint *)malloc(sizeof(WKBPoint));

                    wkbPoint->byteorder = (byte)byteorder;

                    wkbPoint->wkbType = (uint32)WKBPOINT;

                    wkbPoint->point.x = (double)geoptr->value.point_val->x;
                    wkbPoint->point.y = (double)geoptr->value.point_val->y;

                    gresult->geometry_type = WKBPOINT;
                    gresult->value.point = wkbPoint;
                }
                break;
            case LINESTRING:
                { 
                    WKBLineString *wkbLineString = 
                        (WKBLineString *)malloc(sizeof(WKBLineString));

                    wkbLineString->byteorder = (byte)byteorder;

                    wkbLineString->wkbType = (uint32)WKBLINESTRING;

                    /* now count the points and store them */

                    /* first count */
                    ptlist = geoptr->value.linestring_val;
                    do {
                        cnt++;
                        ptlist = ptlist->next;
                    } while (ptlist);
                    wkbLineString->numPoints = (uint32)cnt;
                    wkbLineString->points = (Point *)malloc(cnt * sizeof(Point));

                    ptlist = geoptr->value.linestring_val;
                    cnt = 0;
                    do {
                        wkbLineString->points[cnt].x = ptlist->point->x;
                        wkbLineString->points[cnt].y = ptlist->point->y;

                        cnt++;
                        ptlist = ptlist->next;
                    } while (ptlist);

                    gresult->geometry_type = WKBLINESTRING;
                    gresult->value.linestring = wkbLineString;
                }
                break;
            case POLYGON:
                {
                    WKBPolygon *wkbPolygon =
                        (WKBPolygon *)malloc(sizeof(WKBPolygon));

                    wkbPolygon->byteorder = (byte)byteorder;

                    wkbPolygon->wkbType = (uint32)WKBPOLYGON;

                    /* count the rings in the polygon */
                    linelist = geoptr->value.polygon_val;
                    do {
                        cnt++;
                        linelist = linelist->next;
                    } while (linelist);
                    wkbPolygon->numRings = cnt;
                    /* allocate space for the rings */
                    wkbPolygon->rings = 
                        (LinearRing *)malloc(sizeof(LinearRing) * cnt);

                    /* 
                     * traverse again, counting and storing vertices
                     * in each ring
                     */
                    linelist = geoptr->value.polygon_val;
                    cnt = 0;
                    do {
                        vcnt = 0;
                        /* count the points in each ring */
                        ptlist = linelist->linestring;
                        do {
                            vcnt++;
                            ptlist = ptlist->next;
                        } while ( ptlist );
                        wkbPolygon->rings[cnt].numPoints = vcnt;
                        /* allocate space for the points */
                        wkbPolygon->rings[cnt].points =
                            (Point *)malloc(sizeof(Point) * vcnt);

                        /* store them into the rings */
                        vcnt = 0;
                        ptlist = linelist->linestring;
                        do {
                            wkbPolygon->rings[cnt].points[vcnt].x = 
                                ptlist->point->x;
                            wkbPolygon->rings[cnt].points[vcnt].y = 
                                ptlist->point->y;

                            vcnt++;
                            ptlist = ptlist->next;
                        } while ( ptlist );

                        cnt++;
                        linelist = linelist->next;
                    } while (linelist);

                    gresult->geometry_type = WKBPOLYGON;
                    gresult->value.polygon = wkbPolygon;
                }
                break;
            case MULTIPOINT:
                {
                    WKBMultiPoint *wkbMultiPoint =
                        (WKBMultiPoint *)malloc(sizeof(WKBMultiPoint));

                    wkbMultiPoint->byteorder = (byte)byteorder;

                    wkbMultiPoint->wkbType = (uint32)WKBMULTIPOINT;

                    /* count the points */
                    ptlist = geoptr->value.multipoint_val;
                    do {
                        cnt++;
                        ptlist = ptlist->next;
                    } while (ptlist);
                    wkbMultiPoint->num_wkbPoints = cnt;
                    /* allocate space for the points */
                    wkbMultiPoint->wkbPoints = 
                        (WKBPoint *)malloc(sizeof(WKBPoint) * cnt);

                    /* store the points */
                    cnt = 0;
                    ptlist = geoptr->value.multipoint_val;
                    do {
                        wkbMultiPoint->wkbPoints[cnt].point.x = 
                            ptlist->point->x;
                        wkbMultiPoint->wkbPoints[cnt].point.y = 
                            ptlist->point->y;

                        wkbMultiPoint->wkbPoints[cnt].byteorder = 
                            (byte)byteorder;

                        wkbMultiPoint->wkbPoints[cnt].wkbType = 
                            (uint32)WKBPOINT;

                        cnt++;
                        ptlist = ptlist->next;
                    } while (ptlist);

                    gresult->geometry_type = WKBMULTIPOINT;
                    gresult->value.multipoint = wkbMultiPoint;
                }
                break;
            case MULTILINESTRING:
                {
                    WKBMultiLineString *wkbMultiLineString =
                        (WKBMultiLineString *)malloc(sizeof(WKBMultiLineString));

                    wkbMultiLineString->byteorder = (byte)byteorder;

                    wkbMultiLineString->wkbType = (uint32)WKBMULTILINESTRING;

                    /* count the line strings */
                    linelist = geoptr->value.multilinestring_val;
                    do {
                        cnt++;
                        linelist = linelist->next;
                    } while (linelist);
                    wkbMultiLineString->num_wkbLineStrings = cnt;
                    /* allocate space for the LineStrings */
                    wkbMultiLineString->wkbLineStrings = 
                        (WKBLineString *)malloc(sizeof(WKBLineString) * cnt);

                    /* 
                     * traverse again, counting and storing vertices
                     * in each linestring
                     */
                    cnt = 0;
                    linelist = geoptr->value.multilinestring_val;
                    do {
                        vcnt = 0;
                        /* count the points in each ring */
                        ptlist = linelist->linestring;
                        do {
                            vcnt++;
                            ptlist = ptlist->next;
                        } while ( ptlist );
                        wkbMultiLineString->wkbLineStrings[cnt].numPoints = vcnt;
                        /* allocate space for the points */
                        wkbMultiLineString->wkbLineStrings[cnt].points =
                            (Point *)malloc(sizeof(Point) * vcnt);


                        wkbMultiLineString->wkbLineStrings[cnt].byteorder = 
                            (byte)byteorder;
                        wkbMultiLineString->wkbLineStrings[cnt].wkbType = 
                            (uint32)WKBLINESTRING;

                        /* store them into the line strings */
                        vcnt = 0;
                        ptlist = linelist->linestring;
                        do {
                            wkbMultiLineString->wkbLineStrings[cnt].points[vcnt].x = 
                                ptlist->point->x;
                            wkbMultiLineString->wkbLineStrings[cnt].points[vcnt].y = 
                                ptlist->point->y;

                            vcnt++;
                            ptlist = ptlist->next;
                        } while ( ptlist );

                        cnt++;
                        linelist = linelist->next;
                    } while ( linelist );

                    gresult->geometry_type = WKBMULTILINESTRING;
                    gresult->value.multilinestring = wkbMultiLineString;
                }
                break;
            case MULTIPOLYGON:
                {
                    WKBMultiPolygon *wkbMultiPolygon =
                        (WKBMultiPolygon *)malloc(sizeof(WKBMultiPolygon));

                    wkbMultiPolygon->byteorder = (byte)byteorder;

                    wkbMultiPolygon->wkbType = (uint32)WKBMULTIPOLYGON;

                    /* count the polygons */
                    polylist = geoptr->value.multipolygon_val;
                    do {
                        cnt++;
                        polylist = polylist->next;
                    } while ( polylist );
                    wkbMultiPolygon->num_wkbPolygons = cnt;
                    /* allocate space for the polygons */
                    wkbMultiPolygon->wkbPolygons = 
                        (WKBPolygon *)malloc(sizeof(WKBPolygon) * cnt);

                    /* 
                     * traverse again, counting and storing rings and
                     * then vertices in each ring 
                     */
                    cnt = 0;
                    polylist = geoptr->value.multipolygon_val;
                    do {

                        wkbMultiPolygon->wkbPolygons[cnt].byteorder = (byte)byteorder;
                        wkbMultiPolygon->wkbPolygons[cnt].wkbType = (uint32)WKBPOLYGON;
    
                        /* count the number of rings */
                        rcnt = 0;
                        linelist = polylist->polygon;
                        do {
                            rcnt++;
                            linelist = linelist->next;
                        } while ( linelist );
                        wkbMultiPolygon->wkbPolygons[cnt].numRings = rcnt;
                        /* allocate space for the rings */
                        wkbMultiPolygon->wkbPolygons[cnt].rings = 
                            (LinearRing *)malloc(sizeof(LinearRing) * rcnt);

                        /*
                         *  traverse each ring counting and storing the
                         *  points 
                         */
                        rcnt = 0;
                        linelist = polylist->polygon;
                        do {
                            vcnt = 0;
                            /* count the points in each ring */
                            ptlist = linelist->linestring;
                            do {
                                vcnt++;
                                ptlist = ptlist->next;
                            } while ( ptlist );
                            wkbMultiPolygon->wkbPolygons[cnt].rings[rcnt].numPoints = vcnt;
                            /* allocate space for the points */
                            wkbMultiPolygon->wkbPolygons[cnt].rings[rcnt].points =
                                (Point *)malloc(sizeof(Point) * vcnt);

                            /* store them into the rings */
                            vcnt = 0;
                            ptlist = linelist->linestring;
                            do {
                                wkbMultiPolygon->wkbPolygons[cnt].rings[rcnt].points[vcnt].x = 
                                    ptlist->point->x;
                                wkbMultiPolygon->wkbPolygons[cnt].rings[rcnt].points[vcnt].y = 
                                    ptlist->point->y;

                                vcnt++;
                                ptlist = ptlist->next;
                            } while ( ptlist );

                            rcnt++;
                            linelist = linelist->next;
                        } while ( linelist );

                        cnt++;
                        polylist = polylist->next;
                    } while ( polylist );

                    gresult->geometry_type = WKBMULTIPOLYGON;
                    gresult->value.multipolygon = wkbMultiPolygon;
                }
                break;
        }
    }
}

WKBResult *
build_geoc(GeometryCollection *geocptr)
{
    int cnt = 0;
    GeometryCollection *gcptr = geocptr;

    /* mallocate the result and collection space */
    WKBResult *result = (WKBResult *)malloc(sizeof(WKBResult));
    WKBGeometryCollection *gc = 
        (WKBGeometryCollection *)malloc(sizeof(WKBGeometryCollection));

    /* count the geometries */
    while ( gcptr != NULL ) {
        cnt++;
        gcptr = gcptr->next;
    }
    /* assign byteorder, type, and number of geometries to the collection */
    gc->byteorder = get_byteorder();
    gc->wkbType = WKBGEOMETRYCOLLECTION;
    gc->num_wkbGeometries = cnt;
    /* mallocate space for the geometries */
    gc->wkbGeometries = (WKBGeometry *)malloc(sizeof(WKBGeometry) * cnt);

    /* build the geometries */
    cnt = 0;
    gcptr = geocptr;
    do {
        build_geo(gcptr->geometry, &gc->wkbGeometries[cnt++]);
        gcptr = gcptr->next;
    } while ( gcptr );

    /* populate and return the result */
    result->result_type = WKBGEOMETRYCOLLECTION;
    result->result_value.gc_val = gc;
    return(result);
}

WKBResult *
buildwkb() 
{
    ParsedInput *ptr = global_parsed;

    if ( ptr == NULL ) {
        wkterr = E_NOINPUT;
        sprintf(wkterrmsg,"Oops...parsed nothing\n");
        return(NULL);
    }

    switch(ptr->type) {
        case GEOMETRY:
            {
                /* mallocate the result and geometry space */
                WKBResult *result = (WKBResult *)malloc(sizeof(WKBResult));
                WKBGeometry *gc = (WKBGeometry *)malloc(sizeof(WKBGeometry));

                /* populate and return the result */
                result->result_type = WKBGEOMETRY;
                /* build the geometry */
                build_geo(ptr->value.geometry_val, gc);
                result->result_value.g_val = gc;
                return(result);
            }
            break;
        case GEOMETRYCOLLECTION:
            return(build_geoc(ptr->value.geometrycollection_val));
            break;
    }
}

/* free the data structures */

static void free_parsed_linestring(Linestring * ls)
{
    Linestring * nextp = ls;
    Linestring * thisp;

    while (nextp != 0)
    {
        thisp = nextp;
        nextp = thisp->next;
        free(thisp->point);
        free(thisp);
    }
}

static void free_parsed_linestringlist(LinestringList * lslist)
{
    LinestringList * nextp = lslist;
    LinestringList * thisp;

    while (nextp != 0)
    {
        thisp = nextp;
        nextp = thisp->next;
        free_parsed_linestring(thisp->linestring);
        free(thisp);
    }
}

static void free_parsed_polygonlist(PolygonList * polylist)
{
    PolygonList * nextp = polylist;
    PolygonList * thisp;

    while (nextp != 0)
    {
        thisp = nextp;
        nextp = thisp->next;
        free_parsed_linestringlist(thisp->polygon);
        free(thisp);
    }
}

static void free_parsed_geo(Geometry * geo)
{
    switch (geo->type)
    {
    case (POINT) :
        free(geo->value.point_val);
        break;
    case (LINESTRING) :
        free_parsed_linestring(geo->value.linestring_val);
        break;
    case (POLYGON) :
        free_parsed_linestringlist(geo->value.polygon_val);
        break;
    case (MULTIPOINT) :
        free_parsed_linestring(geo->value.multipoint_val);
        break;
    case (MULTILINESTRING) :
        free_parsed_linestringlist(geo->value.multilinestring_val);
        break;
    case (MULTIPOLYGON) :
        free_parsed_polygonlist(geo->value.multipolygon_val);
        break;
    }
    free(geo);
}

static void free_parsed_geoc(GeometryCollection * geoc)
{
    GeometryCollection * nextp = geoc;
    GeometryCollection * thisp;

    while (nextp != 0)
    {
        thisp = nextp;
        nextp = thisp->next;
        free_parsed_geo(thisp->geometry);
        free(thisp);
    }
}

static void free_parsed_input()
{
    switch (global_parsed->type)
    {
    case GEOMETRY:
        free_parsed_geo(global_parsed->value.geometry_val);
        break;
    case GEOMETRYCOLLECTION:
        free_parsed_geoc(global_parsed->value.geometrycollection_val);
        break;
    }
    free(global_parsed);
}

static void free_geo(WKBGeometry * gresult)
{
    int rcnt, cnt;

    switch (gresult->geometry_type)
    {
    case WKBPOINT:
        free(gresult->value.point);
        break;
    case WKBLINESTRING:
        free(gresult->value.linestring->points);
        free(gresult->value.linestring);
        break;
    case WKBPOLYGON:
        for (cnt = 0; cnt < gresult->value.polygon->numRings; cnt++)
            free(gresult->value.polygon->rings[cnt].points);
        free(gresult->value.polygon->rings);
        free(gresult->value.polygon);
        break;
    case WKBMULTIPOINT:
        free(gresult->value.multipoint->wkbPoints);
        free(gresult->value.multipoint);
        break;
    case WKBMULTILINESTRING:
        for (cnt = 0; cnt < gresult->value.multilinestring->num_wkbLineStrings; cnt++)
            free(gresult->value.multilinestring->wkbLineStrings[cnt].points);
        free(gresult->value.multilinestring->wkbLineStrings);
        free(gresult->value.multilinestring);
        break;
    case WKBMULTIPOLYGON:
        for (cnt = 0; cnt < gresult->value.multipolygon->num_wkbPolygons; cnt++)
        {
            for (rcnt = 0; rcnt < gresult->value.multipolygon->wkbPolygons[cnt].numRings; rcnt++)
                free(gresult->value.multipolygon->wkbPolygons[cnt].rings[rcnt].points);
            free(gresult->value.multipolygon->wkbPolygons[cnt].rings);
        }
        free(gresult->value.multipolygon->wkbPolygons);
        free(gresult->value.multipolygon);
        break;
    }
}

static void free_geoc(WKBResult * result)
{
    int cnt;

    if (result != NULL)
    {
        for (cnt = 0; cnt < result->result_value.gc_val->num_wkbGeometries; cnt++)
            free_geo(&result->result_value.gc_val->wkbGeometries[cnt]);
        free(result->result_value.gc_val->wkbGeometries);
        free(result->result_value.gc_val);
        free(result);
    }
}

void freewkb(WKBResult * result)
{
    if (result != NULL)
    {
        switch (result->result_type)
        {
        case WKBGEOMETRY:
            free_geo(result->result_value.g_val);
            free(result->result_value.g_val);
            free(result);
            break;
        case WKBGEOMETRYCOLLECTION:
            free_geoc(result);
            break;
        }
    }
    free_parsed_input();
}
