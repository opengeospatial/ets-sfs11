/*
** File: wkb2wkt.c 
** Content: This file contains code for processing the Well-Known Binary 
**          format for geometry described in OpenGIS Simle Features for 
**          SQL, Revision 1.0. It accepts Well-Known Binary as input and
**          generates as output the Well-Known Text representation.
**
** Author: Kurt Buehler, Open GIS Consortium, Inc.
** Date: 7/27/1998
**
** Revision History:
**     1.0 - Initial Release, 7/27/1998
**     1.1 - Fixed memory leaks by adding free routines, also added new
**           library routine freewkb(), 8/31/98 
**           Contributed by:
**              Robert Power
**              robert.power@cmis.csiro.au   Software Engineer
**              CSIRO Mathematical and Information Sciences
**              Canberra Laboratory
**              PO Box 664      tel: +61 6 216 7039
**              Canberra ACT 2601 AUSTRALIA.   fax: +61 6 216 7112
**              http://www.cmis.csiro.au/sis
**
*/

/*
** Copyright 1998, Open GIS Consortium, Inc.
**
** WHILE THE SOFTWARE IN THIS FILE IS BELIEVED TO BE ACCURATE, 
** THE OPEN GIS CONSORTIUM MAKES NO WARRANTY OF ANY KIND WITH REGARD TO 
** THIS MATERIAL INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The Open GIS
** Consortium shall not be liable for errors contained herein or for incidental
** or consequential damages in connection with the furnishing, performance or 
** use of this material.
**
** This document contains information, which is protected by copyright. All 
** Rights Reserved. Any part of this work covered by copyright herein may be 
** reproduced or used in any form or by any means graphic, electronic, or 
** mechanical, including photocopying, recording, taping, or information 
** storage and retrieval systems as long as this copyright notice remains.
**
** RESTRICTED RIGHTS LEGEND. Use, duplication, or disclosure by government is 
** subject to restrictions as set forth in subdivision (c)(1)(ii) of the Right 
** in Technical Data and Computer Software Clause at DFARS 252.227.7013
** 
** OpenGIS(R) is a trademark or registered trademark of Open GIS Consortium, 
** Inc. in the United States and in other countries.
*/

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <netinet/in.h>
#include "wkb.h"
#include "grammar.tab.h"

int DEBUG;

int swaporder;

FILE *fpin;
int fdin;
FILE *fpout;
int fdout;

extern int optind;
extern char *optarg;

void usage(char *s);
void get_geometry(uint32 type, FILE *fpin);
uint32 get_wkbType(FILE *fpin);
byte get_hostbyteorder();
byte get_inbyteorder(FILE *fpin);

byte inbyteorder, hostbyteorder;

#ifndef _WKBLIB
char *wkbTypes[] = {
	"",
	"WKBPOINT",
	"WKBLINESTRING",
	"WKBPOLYGON",
	"WKBMULTIPOINT",
	"WKBMULTILINESTRING",
	"WKBMULTIPOLYGON",
	"WKBGEOMETRYCOLLECTION"
};

int
main( int argc, char **argv) 
{
	int use_stdin = 1;
	int use_stdout = 1;
	char *use_file = 0;
	register int c;
	FILE *fp;
	uint32 type;

	DEBUG = 0;
					
	while((c = getopt(argc, argv, "dho:")) != EOF) {
		switch (c) {
			case 'd': 
				DEBUG = 1; 
				break;
			case 'h': 
				usage(argv[0]); 
				exit(1);
				break;
			case 'o':
				if ( (fpout = fopen(optarg, "w")) == NULL ) {
					char errstring[1024];

					sprintf(errstring, "%s: Could not open file \"%s\"\n\tReason",
					argv[0], optarg);
					perror(errstring);
					exit(0);
				}
				use_stdout = 0;
				break;
		}
	}

	if ( optind < argc ) {
		use_file = argv[optind];
		use_stdin = 0;
	} 
											
	if ( use_stdin ) {
		fpin = stdin;
	} else if ( (fpin = fopen(use_file, "r")) == NULL ) {
		char errstring[1024];

		sprintf(errstring, "%s: Could not open file \"%s\"\n\tReason",
		argv[0], use_file);
		perror(errstring);
		exit(0);
	}
											
	if ( use_stdout ) {
		fpout = stdout;
	} 
	fdout = fileno(fpout);

	hostbyteorder = get_hostbyteorder();
	inbyteorder = get_inbyteorder(fpin);

	swaporder = 0;
	if ( hostbyteorder != inbyteorder ) swaporder = 1;

	type = get_wkbType(fpin);
	get_geometry(type, fpin);
	fprintf(fpout,"\n");

	exit(1);
}

void
usage(char *s)
{
	fprintf(stderr,"Usage: %s [-dh] [-o output_filename] [input_filename]\n", s);
}
#else /* _WKBLIB */

typedef struct _parts {
	char *s;
	struct _parts *next;
} Part;

Part *parts;
Part *curPart;

char wkberrmsg[1024];
int wkberr;

char *
wkb2wkt(char *filename) 
{
	FILE *fpin;
	size_t len = 0;
	uint32 type;
	char *s;

	if ((fpin = fopen(filename, "r")) == NULL ) {
		wkberr = E_BINFILE;
		sprintf(wkberrmsg, "Cannot open binary input file. \n\tReason: %s",strerror(errno));
		return(NULL);
	}
	hostbyteorder = get_hostbyteorder();

	inbyteorder = get_inbyteorder(fpin);
	if (inbyteorder == -1) {
		wkberr = E_UBO;
		sprintf(wkberrmsg, "Invalid byteorder, must be incorrect binary input.");
		return (NULL);
	}

	swaporder = 0;
	if ( hostbyteorder != inbyteorder ) swaporder = 1;

	type = get_wkbType(fpin);
	if (type == -1) {
		wkberr = E_UT;
		sprintf(wkberrmsg, "Invalid geometry type, must be incorrect binary input.");
		return (NULL);
	}
	get_geometry(type, fpin);

	/* assemble the parts */
	/* add up the space required */
	curPart = parts;
	while (curPart) {
		len += strlen(curPart->s);
		curPart = curPart->next;
	}

	s = (char *)malloc(len + 1);
	bzero((void *)s, len + 1);

	curPart = parts;
	while (curPart) {
		strcat(s, curPart->s);
		free(curPart->s);
		parts = curPart;
		curPart = curPart->next;
		free(parts);
	}
    return(s);
}
#endif /* _WKBLIB */
		
#ifndef _WKBLIB
void
emit_byteorder(byte byteorder)
{
	/* one byte -> byteorder */
	if ( DEBUG ) 
		fprintf(fpout,"Byteorder: %s\n", byteorder ? "WKBNDR":"WKBXDR");
}

void
emit_wkbType(uint32 wkbType)
{
	if ( DEBUG ) fprintf(fpout,"wkbType: %d %s\n", wkbType, wkbTypes[wkbType]);
}
#endif /* _WKBLIB */

void
emit_x(double x)
{
	char t[32];

#ifndef _WKBLIB
	fprintf(fpout, "%f", x);
#else /* _WKBLIB */
	curPart->next = (Part *)malloc(sizeof(Part));
	curPart = curPart->next;
	curPart->next = NULL;
	sprintf(t,"%f",x);
	curPart->s = (char *)strdup(t);
#endif /* _WKBLIB */
}

void
emit_y(double y)
{
	char t[32];

#ifndef _WKBLIB
	fprintf(fpout, " %f", y);
#else /* _WKBLIB */
	curPart->next = (Part *)malloc(sizeof(Part));
	curPart = curPart->next;
	curPart->next = NULL;
	sprintf(t," %f",y);
	curPart->s = (char *)strdup(t);
#endif /* _WKBLIB */
}

void
readswap4(int fildes, uint32 *buf)
{
	if (read(fildes, buf, 4) != 4) {
		fprintf(stderr, "Couldn't read the required number of bytes.\n");
		exit(0);
	}
	if ( swaporder ) {
		if ( inbyteorder == WKBXDR ) {
			*buf = (uint32)ntohl((u_long)*buf);
		} else {
			byte u[4];

			u[0] = ((byte *) buf)[3];
			u[1] = ((byte *) buf)[2];
			u[2] = ((byte *) buf)[1];
			u[3] = ((byte *) buf)[0];
			((byte *) buf)[0] = u[0];
			((byte *) buf)[1] = u[1];
			((byte *) buf)[2] = u[2];
			((byte *) buf)[3] = u[3];
		}
	}
}

void
readswap8(int fildes, double *buf)
{
	if (read(fildes, buf, 8) != 8) {
		fprintf(stderr, "Couldn't read the required number of bytes.\n");
		exit(0);
	}
	if ( swaporder ) {
		if ( inbyteorder == WKBXDR ) {
			u_long u[2];

			u[0] = ((u_long *) buf)[0];
			u[1] = ((u_long *) buf)[1];
			((u_long *) buf)[1] = ntohl(u[0]);
			((u_long *) buf)[0] = ntohl(u[1]);
		} else {
			byte u[8];

			u[0] = ((byte *) buf)[7];
			u[1] = ((byte *) buf)[6];
			u[2] = ((byte *) buf)[5];
			u[3] = ((byte *) buf)[4];
			u[4] = ((byte *) buf)[3];
			u[5] = ((byte *) buf)[2];
			u[6] = ((byte *) buf)[1];
			u[7] = ((byte *) buf)[0];
			((byte *) buf)[0] = u[0];
			((byte *) buf)[1] = u[1];
			((byte *) buf)[2] = u[2];
			((byte *) buf)[3] = u[3];
			((byte *) buf)[4] = u[4];
			((byte *) buf)[5] = u[5];
			((byte *) buf)[6] = u[6];
			((byte *) buf)[7] = u[7];
		}
	}
}

void
get_geometry(uint32 type, FILE *fpin)
{
	int fdin = fileno(fpin);
	int firstPart = 1;

	switch(type) {
		case WKBPOINT:
			{ 
				double d;

#ifndef _WKBLIB
				fprintf(fpout, "POINT( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("POINT( ");
#endif /* _WKBLIB */
				/* read the X */
				readswap8(fdin, &d);
				emit_x(d);

				/* read the Y */
				readswap8(fdin, &d);
				emit_y(d);
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
		case WKBLINESTRING:
			{ 
				double d;
				uint32 n;
				int i;

#ifndef _WKBLIB
				fprintf(fpout, "LINESTRING( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("LINESTRING( ");
#endif /* _WKBLIB */
				/* read the number of vertices */
				readswap4(fdin, &n);

				for ( i = 0; i < n; i++) {
					readswap8(fdin, &d);
					emit_x(d);
					readswap8(fdin, &d);
					emit_y(d);
#ifndef _WKBLIB
					if ( i < n - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
					if ( i < n - 1 ) {
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(", ");
					}
#endif /* _WKBLIB */
				}
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
		case WKBPOLYGON:
			{
				double d;
				uint32 r, v;
				int i, j;

#ifndef _WKBLIB
				fprintf(fpout, "POLYGON( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("POLYGON( ");
#endif /* _WKBLIB */
				/* read the number of rings */
				readswap4(fdin, &r);

				for ( i = 0; i < r; i++ ) {
#ifndef _WKBLIB
					fprintf(fpout, "( ");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup("( ");
#endif /* _WKBLIB */
					/* read the number of vertices */
					readswap4(fdin, &v);
					
					for ( j = 0; j < v; j++ ) {
						readswap8(fdin, &d);
						emit_x(d);
						readswap8(fdin, &d);
						emit_y(d);
#ifndef _WKBLIB
						if ( j < v - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
						if ( j < v - 1 ) {
							curPart->next = (Part *)malloc(sizeof(Part));
							curPart = curPart->next;
							curPart->next = NULL;
							curPart->s = (char *)strdup(", ");
						}
#endif /* _WKBLIB */
					}
#ifndef _WKBLIB
					fprintf(fpout, " )");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
#ifndef _WKBLIB
					if ( i < r - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
					if ( i < r - 1 ) {
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(", ");
					}
#endif /* _WKBLIB */
				}
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
		case WKBMULTIPOINT:
			{
				double d;
				byte b;
				uint32 n, u;
				int i;

#ifndef _WKBLIB
				fprintf(fpout, "MULTIPOINT( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("MULTIPOINT( ");
#endif /* _WKBLIB */
				/* read the number of points */
				readswap4(fdin, &n);

				for ( i = 0; i < n; i++ ) {
					/* read (and ignore) the byteorder and type */
					b = get_inbyteorder(fpin);
					u = get_wkbType(fpin);

#ifndef _WKBLIB
					fprintf(fpout, " ( ");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup(" ( ");
#endif /* _WKBLIB */

					/* read the X */
					readswap8(fdin, &d);
					emit_x(d);

					/* read the Y */
					readswap8(fdin, &d);
					emit_y(d);

#ifndef _WKBLIB
					fprintf(fpout, " )");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
#ifndef _WKBLIB
					if ( i < n - 1 ) fprintf( fpout, ", ");
#else /* _WKBLIB */
					if ( i < n - 1 ) {
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(", ");
					}
#endif /* _WKBLIB */
				}
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
		case WKBMULTILINESTRING:
			{
				double d;
				uint32 l, v;
				byte b;
				uint32 u;
				int i, j;

#ifndef _WKBLIB
				fprintf(fpout, "MULTILINESTRING( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("MULTILINESTRING( ");
#endif /* _WKBLIB */
				/* read the number of line strings */
				readswap4(fdin, &l);

				for ( i = 0; i < l; i++ ) {
					/* read byteorder and type */
					b = get_inbyteorder(fpin);
					u = get_wkbType(fpin);
					
#ifndef _WKBLIB
					fprintf(fpout, "( ");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup("( ");
#endif /* _WKBLIB */
					/* read the number of vertices */
					readswap4(fdin, &v);

					for ( j = 0; j < v; j++ ) {
						/* read the X */
						readswap8(fdin, &d);
						emit_x(d);

						/* read the Y */
						readswap8(fdin, &d);
						emit_y(d);
#ifndef _WKBLIB
						if ( j < v - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
						if ( j < v - 1 ) {
							curPart->next = (Part *)malloc(sizeof(Part));
							curPart = curPart->next;
							curPart->next = NULL;
							curPart->s = (char *)strdup(", ");
						}
#endif /* _WKBLIB */
					}
#ifndef _WKBLIB
					fprintf(fpout, " )");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
#ifndef _WKBLIB
					if ( i < l - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
					if ( i < l - 1 ) {
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(", ");
					}
#endif /* _WKBLIB */
				}
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
		case WKBMULTIPOLYGON:
			{
				double d;
				uint32 p, r, v;
				int i, j, k;
				byte b;
				uint32 u;

#ifndef _WKBLIB
				fprintf(fpout, "MULTIPOLYGON( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("MULTIPOLYGON( ");
#endif /* _WKBLIB */
				/* read the number of polygons */
				readswap4(fdin, &p);

				for ( i = 0; i < p; i++ ) {
					/* read byteorder and type */
					b = get_inbyteorder(fpin);
					u = get_wkbType(fpin);
					
#ifndef _WKBLIB
					fprintf(fpout, "( ");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup("( ");
#endif /* _WKBLIB */
					/* read the number of rings */
					readswap4(fdin, &r);
					
					for ( j = 0; j < r; j++ ) {
#ifndef _WKBLIB
						fprintf(fpout, "( ");
#else /* _WKBLIB */
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup("( ");
#endif /* _WKBLIB */
						/* read the number of vertices */
						readswap4(fdin, &v);
						
						for ( k = 0; k < v; k++ ) {
							readswap8(fdin, &d);
							emit_x(d);
							readswap8(fdin, &d);
							emit_y(d);
#ifndef _WKBLIB
							if ( k < v - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
							if ( k < v - 1 ) {
								curPart->next = (Part *)malloc(sizeof(Part));
								curPart = curPart->next;
								curPart->next = NULL;
								curPart->s = (char *)strdup(", ");
							}
#endif /* _WKBLIB */
						}
#ifndef _WKBLIB
						fprintf(fpout, " )");
#else /* _WKBLIB */
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
#ifndef _WKBLIB
						if ( j < r - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
						if ( j < r - 1 ) {
							curPart->next = (Part *)malloc(sizeof(Part));
							curPart = curPart->next;
							curPart->next = NULL;
							curPart->s = (char *)strdup(", ");
						}
#endif /* _WKBLIB */
					}
#ifndef _WKBLIB
					fprintf(fpout, " )");
#else /* _WKBLIB */
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
					curPart->next = NULL;
					curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
#ifndef _WKBLIB
					if ( i < p - 1 ) fprintf(fpout, ", ");
#else /* _WKBLIB */
					if ( i < p - 1 ) {
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(", ");
					}
#endif /* _WKBLIB */
				}
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
		case WKBGEOMETRYCOLLECTION:
			{
				uint32 g;
				int i;

#ifndef _WKBLIB
				fprintf(fpout, "GEOMETRYCOLLECTION( ");
#else /* _WKBLIB */
				if ( firstPart ) {
					parts = (Part *)malloc(sizeof(Part));
					curPart = parts;
				} else {
					curPart->next = (Part *)malloc(sizeof(Part));
					curPart = curPart->next;
				}
				curPart->next = NULL;
				curPart->s = (char *)strdup("GEOMETRYCOLLECTION( ");
#endif /* _WKBLIB */
				/* read the number of geometries */
				readswap4(fdin, &g);

				for ( i = 0; i < g; i++ ) {
					byte b;
					
					b = get_inbyteorder(fpin);

					get_geometry(get_wkbType(fpin), fpin);
#ifndef _WKBLIB
					if ( i < g - 1) fprintf(fpout, ", ");
#else /* _WKBLIB */
					if ( i < g - 1) {
						curPart->next = (Part *)malloc(sizeof(Part));
						curPart = curPart->next;
						curPart->next = NULL;
						curPart->s = (char *)strdup(", ");
					}
#endif /* _WKBLIB */
				}
#ifndef _WKBLIB
				fprintf(fpout, " )");
#else /* _WKBLIB */
				curPart->next = (Part *)malloc(sizeof(Part));
				curPart = curPart->next;
				curPart->next = NULL;
				curPart->s = (char *)strdup(" )");
#endif /* _WKBLIB */
			}
			break;
	}
}

byte
get_hostbyteorder()
{
    u_short host = 5;
	u_short net;

	net = htons(host);
	if ( net == host )
		return(WKBXDR);
	else
		return(WKBNDR);
}

byte
get_inbyteorder(FILE *fpin)
{
    byte b;
	int fdin = fileno(fpin);


	uint32 wkbType;

	/* read the byteorder */
	read(fdin, &b, 1);

	if (b != WKBNDR && b != WKBXDR) {
#ifndef _WKBLIB
		fprintf(stderr, "Unknown byteorder\n");
		exit(0);
#else /* _WKBLIB */
		return(-1);
#endif /* _WKBLIB */
	}

#ifndef _WKBLIB
	emit_byteorder(b);
#endif /* _WKBLIB */

	return(b);
}

uint32
get_wkbType(FILE *fpin)
{
    uint32 u;
	int fdin = fileno(fpin);


	/* read the type */
	readswap4(fdin, &u);

	if (u > WKBMAXTYPE || u < WKBMINTYPE) {
#ifndef _WKBLIB
		fprintf(stderr, "Unknown type\n");
		exit(0);
#else /* _WKBLIB */
		return(-1);
#endif /* _WKBLIB */
	}

#ifndef _WKBLIB
  	emit_wkbType(u);   
#endif /* _WKBLIB */
	
	return(u);
}
