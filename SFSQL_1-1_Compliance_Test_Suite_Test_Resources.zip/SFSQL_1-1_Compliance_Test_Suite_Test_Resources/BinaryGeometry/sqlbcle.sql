-- FILE: sqlbcle.sql 10/01/98
--
-- *** ADAPTATION ALERT ***
-- OGC will not examine this script for adaptations.
-- Please add any other cleanup to this script.
-- 
DROP TABLE geometry_columns;
DROP TABLE spatial_ref_sys;
DROP TABLE lake_geom;
DROP TABLE road_segment_geom;
DROP TABLE divided_route_geom;
DROP TABLE forest_geom;
DROP TABLE bridge_geom;
DROP TABLE stream_geom;
DROP TABLE building_pt_geom;
DROP TABLE building_area_geom;
DROP TABLE pond_geom;
DROP TABLE named_place_geom;
DROP TABLE map_neatline_geom;
DROP TABLE lakes;
DROP TABLE road_segments;
DROP TABLE divided_routes;
DROP TABLE forests;
DROP TABLE bridges;
DROP TABLE streams;
DROP TABLE buildings;
DROP TABLE ponds;
DROP TABLE named_places;
DROP TABLE map_neatlines;
