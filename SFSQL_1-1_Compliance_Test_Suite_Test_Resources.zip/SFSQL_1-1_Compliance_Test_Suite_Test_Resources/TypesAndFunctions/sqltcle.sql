-- FILE: sqltcle.sql 10/01/98
--
-- *** ADAPTATION ALERT ***
-- OGC will not examine this script for adaptations.
-- Please add any other cleanup to this script.
-- 
DROP TABLE spatial_ref_sys;
DROP TABLE lakes;
DROP TABLE road_segments;
DROP TABLE divided_routes;
DROP TABLE forests;
DROP TABLE bridges;
DROP TABLE streams;
DROP TABLE buildings;
DROP TABLE ponds;
DROP TABLE named_places;
DROP TABLE map_neatlines;
